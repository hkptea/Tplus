<?php
namespace Bar\baz;
const ITEMS_PER_PAGE = 50;
function bar() {

	return 'from namespace function';
}