<?php
namespace Widget;

class Calender {
	const MONTH = ['march'=>3];
	public static function draw() {
		return '달력위젯이 그림';
	}
}