<?php /* Tplus 1.0.3 2023-01-09 19:25:06 D:\Work\Tplus\test\html\sub.html 000000142 */ ?>
<div><?= $V["fooo"][3] ?> <?= $V["fooo"][3] ?></div>