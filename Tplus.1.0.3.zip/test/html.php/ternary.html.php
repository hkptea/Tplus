<?php /* Tplus 1.0 Beta 2023-01-14 23:44:30 D:\Work\tpl\test\html\ternary.html 000000129 */ ?>
<?= ($V["bar"]?'foobar':'foo') ?>
