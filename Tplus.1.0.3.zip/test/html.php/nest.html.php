<?php /* Tplus 1.0 Beta 2023-01-10 05:02:31 D:\Work\tpl\test\html\nest.html 000000175 */ ?>
<html>
<body>
	<?= \Tpl::get('sub.html',['fooo'=>[3,4,5,6,7,8]]) ?>
</body>
</html>