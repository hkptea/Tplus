<?php /* Tplus 1.0 Beta 2 2023-02-04 21:53:56 D:\Work\tpl\test\html\intro\intro.html 000000442 */ ?>
<?php $L1=[1,2];if (is_array($L1) and !empty($L1)) {$L1s=count($L1);$L1i=-1;foreach($L1 as $L1k=>$L1v) { ++$L1i; ?>
<?php $L2=[3,4,5];if (is_array($L2) and !empty($L2)) {$L2s=count($L2);$L2i=-1;foreach($L2 as $L2k=>$L2v) { ++$L2i; ?>
	   <?= $L1v ?> x <?= $L2v ?> = <?= $L1v*$L2v ?> <br/>
<?php }} ?>
<?php }} ?>



김성중님 문의사항